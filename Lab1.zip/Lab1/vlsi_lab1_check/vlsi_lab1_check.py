import sys
import re


NUM_BITS = 12


class BitSequenceError(Exception):
    pass


def find_all_occurrences(all_bits, sequence_bits):
    indexes = [m.start() for m in re.finditer('(?={0})'.format(re.escape(sequence_bits)), all_bits)]
    num_seq_in_seq = 0
    for jj in range(len(indexes)-1):
        num = indexes[jj+1] - indexes[jj]
        if num < NUM_BITS:
            num_seq_in_seq += 1
    return indexes, num_seq_in_seq


def main(argv):
    bit_sequence = '100111100110' if len(argv) < 2 else argv[1]

    try:
        if bit_sequence is None:
            raise BitSequenceError
        with open("bits.txt") as bits_file:
            all_bits = bits_file.readline()                 # reading contents of the file as string values
            indexes, num_seq_in_seq = find_all_occurrences(all_bits, bit_sequence)
            print(f'No. of occurrences (total) \t No. of sequence in sequence')
            print(f'{len(indexes)} \t\t\t\t {num_seq_in_seq}')
            output_file = open("sequence_data.txt",'w')
            output_file.write('No. of occurrences (total) \t No. of sequence in sequence\n')
            output_file.write(f'{len(indexes)} \t\t\t\t {num_seq_in_seq}')
            output_file.close()
            output_file= open('sequence_data.txt')
            content = output_file.read()
            output_file.close()
    except FileNotFoundError:
        print("Error: File bits.txt is not provided")
    except BitSequenceError:
        print("Error: Bit sequence is missing")

    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
